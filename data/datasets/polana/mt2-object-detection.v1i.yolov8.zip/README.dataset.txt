# mt2-object-detection > 2024-02-19 12:39am
https://universe.roboflow.com/metin2visionbot/mt2-object-detection

Provided by a Roboflow user
License: CC BY 4.0

